import random
import matplotlib.pyplot as plt

# 掷骰子的次数
num_rolls = 1000

# 存储每次实验的累计频率
cumulative_frequencies = []

# 初始频率为0
frequency = 0

for i in range(1, num_rolls+1 ):
    # 随机掷骰子，并记录结果
    roll = random.randint(1, 6)

    # 如果掷出的结果是6，则增加频率
    if roll == 6:
        frequency += 1

    # 计算累计频率并存储
    cumulative_frequency = frequency / i
    cumulative_frequencies.append(cumulative_frequency)

# 绘制累计频率随投掷次数的变化图
plt.plot(range(1, num_rolls + 1), cumulative_frequencies)
plt.axhline(y=1/6, color='r', linestyle='--', label='Theoretical Probability')
plt.xlabel('Number of Rolls')
plt.ylabel('Cumulative Frequency')
plt.title('Law of Large Numbers')
plt.legend()
plt.show()