import random

wish = 0
repeat = int(1e7)

WishCount = 0
character = [0] * 90

for times in range(repeat):
    while True:
        wish += 1
        P = ((wish - 73) + abs(wish - 73)) / 2 * 0.06 + 0.006
        if P > random.random():
            WishCount += wish
            character[wish-1] += 1
            wish = 0
            break

result1 = "IT TAKES AN AVERAGE OF " + str(WishCount/repeat) + " WISHES TO GET A 5-Star HERO."

notUP = 0
wishUP = 0
WishCount = 0
characterUP = [0] * 180

for times in range(repeat):
    while True:
        wish += 1
        wishUP += 1
        P = ((wish - 73) + abs(wish - 73)) / 2 * 0.06 + 0.006
        if P > random.random():
            wish = 0
            if random.random() > 0.5 or notUP == 1:
                characterUP[wishUP-1] += 1
                WishCount += wishUP
                notUP = 0
                wishUP = 0
                break
            else:
                notUP = 1

result2 = "IT TAKES AN AVERAGE OF " + str(WishCount/repeat) + " WISHES TO GET A 5-Star-UP HERO."

print(result1)
print(result2)